/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Application delegate.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var window: UIWindow?
}
