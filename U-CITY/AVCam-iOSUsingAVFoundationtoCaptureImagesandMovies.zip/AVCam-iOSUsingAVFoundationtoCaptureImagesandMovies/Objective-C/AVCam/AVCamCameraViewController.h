/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
View controller for camera interface.
*/

@import UIKit;

@interface AVCamCameraViewController : UIViewController

@end
